import axios from "axios"
import { browserHistory } from "react-router"
import * as types from "../constants"

function Login() {
	return { type: types.MANUAL_LOGIN_USER }
}

function Success(data) {
	return { 
		type: types.LOGIN_SUCCESS_USER,
		data
	}
}

function loginError(data) {
	return { type: types.LOGIN_ERROR_USER,
	data }
}



export function userLogin(data) {	
	return dispatch => {
		dispatch(Login())
		axios.get( `https://swapi.co/api/people/?search=${data.username}`).then(res => {
			
		if(res.data.results.length){
			if(res.data.results[0].birth_year == data.password){
				dispatch(Success(data));
				browserHistory.push('/search');
			}
			else
		{
			dispatch(loginError(data));
			alert("wrong username/password!!")
			let loginMessage = "wrong username / password"
			return loginMessage	
		}

		}
		
		else
		{
			dispatch(loginError(data));
			alert("wrong username/password!!")
			let loginMessage = "wrong username / password"
			return loginMessage	
		}
		})			
	}
}

export function Logout() {
	browserHistory.push("/") // logout to home page	
}
