import React, { Component } from 'react'

export default class Navigation extends Component {
	
	_logout (event){
		event.preventDefault()
		alert("Hi I am logout");
		this.props.manualLogout()
	}



	render() {
		
		return (
			<div >				
			
			</div>
		)
	}
}

