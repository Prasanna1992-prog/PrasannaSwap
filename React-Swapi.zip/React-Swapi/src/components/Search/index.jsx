import React, { PropTypes } from 'react';
import './search.scss';
import { Logout } from '../../actions/users';

const Search = (props) => {
  const { value, onChange } = props;

  return (
    <div>
      <h2 className='search'>Searching Data</h2>
      <div>
        <input
          type="text" className="searchicon"
          placeholder="Enter a search term"
          onChange={e => onChange(e.target.value)}
          value={value}
          autoFocus
        />
      </div>
      <button className='search_button' onClick={Logout}>Log Out</button>
    </div>
  );
};

Search.propTypes = {
  value: PropTypes.string,
  onChange: PropTypes.func,
};

export default Search;
