import React, { PropTypes } from 'react';

const Planet = props => (
  <li className="items">
    <h3 className="title">
      {props.item.name}
    </h3>
    <div
      className="results__bg"
      id={props.item.type}
     />
    <ul className="info">
      <li>Terrain <h3>{props.item.terrain}</h3> </li>
      <li>Gravity <h3>{props.item.gravity}</h3> </li>
      <li>Population <h3>{props.item.population}</h3> </li>
    </ul>
  </li>
);

Planet.propTypes = {
  item: PropTypes.shape({
    terrain: PropTypes.string,
    gravity: PropTypes.string,
    name: PropTypes.string.isRequired,
    population: PropTypes.string,
    type: PropTypes.string,
  }),
};

export default Planet;
