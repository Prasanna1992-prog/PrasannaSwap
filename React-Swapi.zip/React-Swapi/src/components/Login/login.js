import React, { Component } from 'react'
import LoginForm from "./loginForm";



export default class Login extends Component {
    render() {
        return (
            <div>
            <h3 style={{ textAlign: 'center'}}> Login Screen </h3>
            <LoginForm  user={this.props.user} />
            </div>
        )
    }
  
}



  

